package com.test.riding_helper;

import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import org.jetbrains.annotations.NotNull;

public class TiltSetting extends AppCompatActivity implements CompoundButton.OnCheckedChangeListener, View.OnClickListener {
    boolean isHardMode = false; // 높은 경사도 체크 여부
    boolean isSave = false; // 정보 저장
    String str1, str2;
    int min_gradient = 5; // 경사도 최소 : 디폴트 5
    int max_gradient = 15; // 경사도 최대 : 디폴트 15
    EditText min, max;
    CheckBox hardCheck = (CheckBox) findViewById(R.id.tiltcheck);
    Button saveButton = (Button) findViewById(R.id.save_btn);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        setContentView(R.layout.activity_tilt);
        hardCheck.setOnCheckedChangeListener(this);
        saveButton.setOnClickListener(this);
        initSetting();
    }

    private void initSetting() {
        min = findViewById(R.id.tilt_min);
        min.setVisibility(View.VISIBLE);
        str1 = min.getText().toString();

        if(str1.length() == 0)
        {
            min_gradient = 5;   // 디폴트 5
        }
        else
        {
            min_gradient = Integer.parseInt(str1);  // 최소 경사도 입력
        }

        max = findViewById(R.id.tilt_max);
        max.setVisibility(View.VISIBLE);
        str2 = max.getText().toString();
        if(str2.length() == 0)
        {
            max_gradient = 15;  // 디폴트 15
        }
        else
        {
            max_gradient = Integer.parseInt(str2);  // 최대 경사도 입력
        }

        isSave = false; // 세이브 X 상태

        min.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable editable) {
                // 입력이 끝났을 때
                min_gradient = Integer.parseInt(editable.toString());
            }
        });

        max.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable editable) {
                // 입력이 끝났을 때
                max_gradient = Integer.parseInt(editable.toString());
            }
        });


    }

    @Override
    public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
        if(hardCheck.isChecked())
        {
            isHardMode = true;  // 어려운 경사 모드 true로 변환.
        }
    }

    @Override
    public void onClick(View view) {
        isSave = true;
        // min_gradient, max_gradient, isHardMode를 전달해주도록 추가해주시겠어요?
    }
}
