package com.test.riding_helper;

import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class TiltSetting extends AppCompatActivity {
    boolean isHardMode = false; // 높은 경사도 체크 여부
    boolean isSave = false; // 정보 저장
    String str1, str2;
    int min_gradient = 5; // 경사도 최소 : 디폴트 5
    int max_gradient = 15; // 경사도 최대 : 디폴트 15
    EditText min, max;

    private void initSetting() {
        min = findViewById(R.id.tilt_min);
        min.setVisibility(View.VISIBLE);
        str1 = min.getText().toString();
        if(str1.length() == 0)
        {
            min_gradient = 5;
        }
        else
        {
            min_gradient = Integer.parseInt(str1);
        }

        max = findViewById(R.id.tilt_max);
        max.setVisibility(View.VISIBLE);
        str1 = min.getText().toString();
        if(str1.length() == 0)
        {
            max_gradient = 15;
        }
        else
        {
            max_gradient = Integer.parseInt(str2);
        }
        isSave = false; // 정보 저장
    }
}
